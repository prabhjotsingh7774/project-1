package com.project;

public interface PayRoll {

	double computePayRoll();
	
}
