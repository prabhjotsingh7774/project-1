import static org.junit.Assert.*;

import java.util.ArrayList;

import org.junit.*;
import com.project.*;

public class AllTest {

	@Test
    public void testTeacherComputePayRoll() {
        System.out.println("Test: Calculate payroll for a "
                + "full-time teacher with bachelor's degree.");
        Teacher instance = new FullTimeTeacher
        ("Evan", 1, 2021, "Male", 1001, "Computer Science", "Bachelor");
        double expResult = 2284.80;
        double result = instance.computePayRoll();
        assertEquals(expResult, result, 0.0001);
    }

    @Test
    public void testTeacherDetermineBonus() {
        System.out.println("Test: Calculate bonus for a "
                + "full-time teacher with a PhD.");
        Teacher instance = new FullTimeTeacher
        ("Evan", 1, 2021, "Male", 1001, "Computer Science", "PhD");
        double expResult = 1350.0;
        double result = instance.determineBonus();
        assertEquals(expResult, result, 0.0);
    }
    
    @Test
    public void testTeacherComputePayRollPartTime() {
        System.out.println("Test: Calculate payroll for a "
                + "part-time teacher with a master's degree.");
        Teacher instance = new PartTimeTeacher
        ("Evan", 1, 2021, "Male", 1001, "Computer Science", "Master", 32);
        double expResult = 3988.48;
        double result = instance.computePayRoll();
        assertEquals(expResult, result, 0.0001);
    }

    @Test
    public void testTeacherDetermineBonusPartTime() {
        System.out.println("Test: Calculate bonus for a "
                + "part-time teacher with a PhD, who is working overtime.");
        Teacher instance = new PartTimeTeacher
        ("Evan", 1, 2021, "Male", 1001, "Computer Science", "PhD", 50);
        double expResult = 750.0;
        double result = instance.determineBonus();
        assertEquals(expResult, result, 0.0);
    }
    
    @Test
    public void testStaffComputePayRoll() {
        System.out.println("Test: Calculate payroll for a staff member.");
        Staff instance = new Staff
        ("Yet Another Evan", 17, 2004, "Male", 1024, "mogus", 25);
        double expResult = 1200;
        double result = instance.computePayRoll();
        assertEquals(expResult, result, 0.0001);
    }
    
    @Test
    public void testStaffComputePayRollOvertime() {
        System.out.println("Test: Calculate payroll for a staff member "
                + "working overtime.");
        Staff instance = new Staff
        ("Yet Another Evan", 17, 2004, "Male", 1024, "mogus", 45);
        double expResult = 1920;
        double result = instance.computePayRoll();
        assertEquals(expResult, result, 0.0001);
    }

    @Test
    public void testStaffDetermineBonus() {
        System.out.println("Test: Calculate bonus for a staff member.");
        Staff instance = new Staff
        ("Yet Another Evan", 17, 2015, "Male", 1024, "mogus", 32);
        double expResult = 103;
        double result = instance.determineBonus();
        assertEquals(expResult, result, 0.01);
    }
    
    @Test
    public void testDepartmentAddTeacher() {
        System.out.println("Test: Add teacher to a department.");
        Teacher teacher = new FullTimeTeacher("Evan", 1, 2021, "Male", 20212, "Computer Science", "PhD");
        Department instance = new Department("Computer Science", 0, 0, 
                new ArrayList<Teacher>(), new ArrayList<Staff>(), "csDept");
        instance.addTeacher(teacher);
    }

    @Test
    public void testDepartmentAddStaff() {
        System.out.println("Test: Add staff member to a department.");
        Staff staffMember = new Staff("Also Evan", 2, 2021, "Male", 10093, "H", 21);
        Department instance = new Department("Computer Science", 0, 0,
                new ArrayList<Teacher>(), new ArrayList<Staff>(), "csDept");
        instance.addStaff(staffMember);
    }

    @Test
    public void testDepartmentRemoveTeacher() {
        System.out.println("Test: Remove teacher from a department.");
        Teacher teacher = new FullTimeTeacher("Evan", 1, 2021, "Male", 20212, "Computer Science", "PhD");
        Department instance = new Department("Computer Science", 0, 0, 
                new ArrayList<Teacher>(), new ArrayList<Staff>(), "csDept");
        instance.removeTeacher(teacher);
    }

    @Test
    public void testDepartmentRemoveStaff() {
        System.out.println("Test: Remove staff member from a department.");
        Staff staffMember = new Staff("Also Evan", 2, 2021, "Male", 10093, "H", 21);
        Department instance = new Department("Computer Science", 0, 0,
                new ArrayList<Teacher>(), new ArrayList<Staff>(), "csDept");
        instance.removeStaff(staffMember);
    }

    @Test
    public void testDepartmentLoadDept() {
        System.out.println("Test: Load a department.");
        String name = "mathDept";
        Department instance = new Department("Math", 0, 0,
                new ArrayList<Teacher>(), new ArrayList<Staff>(), name);
        instance.loadDept(name);
    }

    @Test
    public void testDepartmentSaveDept() {
        System.out.println("Test: Save a department.");
        String name = "csDept";
        Department instance = new Department("Test", 0, 0,
                new ArrayList<Teacher>(), new ArrayList<Staff>(), name);
        instance.saveDept("testDept");
    }

    @Test
    public void testDepartmentVerifyDean() {
        System.out.println("Test: Verify whether there is a valid "
                + "dean in a department");
        Department instance = new Department("Computer Science", 10001, 1001,
                new ArrayList<Teacher>(), new ArrayList<Staff>(), "csDept");
        boolean expResult = true;
        boolean result = instance.verifyDean();
        assertEquals(expResult, result);
    }
}
